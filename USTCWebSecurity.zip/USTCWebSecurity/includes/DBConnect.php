<?php
define("HOST", "127.0.0.1");
define("USER", "root");
define("PASS_WORD", "root");
define("DB_NAME", "websecurity");

function getConnection(){
    return mysqli_connect(HOST,USER,PASS_WORD, DB_NAME);
}
